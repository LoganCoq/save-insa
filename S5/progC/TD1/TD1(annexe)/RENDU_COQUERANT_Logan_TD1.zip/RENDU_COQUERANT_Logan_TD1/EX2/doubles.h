#ifndef _DOUBLES_H
#define _DOUBLES_H

#define ZERO 1e-100
#define EPSILON 1e-10

extern int proche(double,double);

#endif
