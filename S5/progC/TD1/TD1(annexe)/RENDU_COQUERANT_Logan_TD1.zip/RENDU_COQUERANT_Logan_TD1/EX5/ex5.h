#ifndef _EX5_H
#define _EX5_H

int chaine_indice(char s1[], char s2[]);

#endif
