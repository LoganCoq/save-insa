#include "ex6.h"
#include <math.h>

void elever_au_cube(int * p)
{
    *p = (*p)*(*p);
}
