#ifndef _EX6_H
#define _EX6_H

extern void elever_au_cube( int* p);

#endif
