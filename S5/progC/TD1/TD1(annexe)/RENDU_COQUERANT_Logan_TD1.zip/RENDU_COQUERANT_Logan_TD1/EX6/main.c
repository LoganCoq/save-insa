#include <stdio.h>
#include <stdlib.h>
#include "ex6.h"

int main(void)
{
    int n = 5;
    elever_au_cube(&n);
    printf("%d\n", n);

    return 0;
}
