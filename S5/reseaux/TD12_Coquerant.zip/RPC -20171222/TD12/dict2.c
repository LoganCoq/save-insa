#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "dict.h"

#include "DictProcedures.hc"
