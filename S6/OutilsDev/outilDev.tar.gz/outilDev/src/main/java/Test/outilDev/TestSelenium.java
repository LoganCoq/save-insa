package Test.outilDev;


import java.util.concurrent.TimeUnit;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import john.MathsUtils;


public class TestSelenium {
	
    private WebDriver driver;
    private String baseUrl;
    private StringBuffer verificationErrors = new StringBuffer();
    
    
    @Before
    public void setUp() throws Exception {
	    // On instancie notre driver, et on configure notre temps d’attente
	    System.setProperty("webdriver.chrome.driver","/home/lbobelin/Downloads/chromedriver");
	    
	    driver = new ChromeDriver();
	    baseUrl = "http://localhost/";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }
    
    
    @Test
    public void testSelenium() throws Exception {
	    // On se connecte au site
	    driver.get(baseUrl + "lcm.html");
	    
	    // Bon, comment est le titre ?
	    String expectedTitle = "Welcome to LCM calculator !";
	    String actualTitle = "";
	    
	    
	    // get the actual value of the title
	    actualTitle = driver.getTitle();
	    assert(expectedTitle.equals(actualTitle));
	    
	    // Remplissons le formulaire
	    driver.findElement(By.id("inputText")).clear();
	    driver.findElement(By.id("outputText")).clear();
	    driver.findElement(By.id("inputText")).sendKeys("3, 4");
	    driver.findElement(By.id("button1")).click();
	    
	    // Verification du lien jar
	    List<WebElement> link = driver.findElements(By.tagName("a"));
	    for (int i = 0 ; i < link.size() ; i++){
	    	if(link.get(i).getAttribute("href").equals("johnArithmetics.jar")) assert(true);
	    }
	    
	    // Quelle est donc cette valeur ? Vérifions avec notre bonne version d’Arithmetics !
	    String maybeLCM = driver.findElement(By.id("outputText")).getAttribute("value");
	    System.out.println(maybeLCM + " is the value calculated by the web page");
	    int lcm = MathsUtils.johnCorrectPPCM(3,4);
	    String Slcm = String.valueOf(lcm);
	    assert(maybeLCM.equals(Slcm));
	    {
	    	
	    }
    }

    
	@After
	public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	    	// fail(verificationErrorString);
	    }
	}
}
